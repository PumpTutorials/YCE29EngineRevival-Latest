Welcome to your new YoshiCrafter Engine mod.

No need to remove README.txt files, since they're automatically ignored when your release is made.

I recommend checking around the Toolbox, and if you want to go deeper, each folder here have a readme file that contains information about it.

Enjoy!