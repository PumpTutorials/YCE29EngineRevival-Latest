== DROP YOUR CHARTS AND SCRIPTS HERE ==

Example Charts & Scripts Tree:
└───data
    └───your-song
	│   your-song-hard.json
	│   your-song.json
	│   your-song-easy.json
	│   script.lua
	│   script but haxe.hx