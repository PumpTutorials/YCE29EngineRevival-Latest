== DROP YOUR CUSTOM SPRITES HERE ==

Sprites can be created this way:

[HAXE]	new ModSprite("My Sprite Script");